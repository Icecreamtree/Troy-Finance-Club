/* Place your JavaScript in this file */
let btn = document.getElementById("Start") {
    while btnn
}
let btn = document.getElementById("Stop") {
    function replaceContent () {	
    document.body.innerHTML = “CLICKED!!!”
    }
    btn.onclick = replaceContent;
}
